export default function TabNavigation() {
  // Tab navigation is now integrated into the dashboard itself
  // All functionality is accessible through the tabbed interface
  return null;
}
